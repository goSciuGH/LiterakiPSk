var class_dictionary =
[
    [ "Dictionary", "class_dictionary.html#aee8d612bc9d323c38faba045ba384b8b", null ],
    [ "~Dictionary", "class_dictionary.html#aa36f24073d9c9001768517aa2322cb82", null ],
    [ "loadDictionary", "class_dictionary.html#a4162ceb3ee58084fda0062656f616dbf", null ],
    [ "searchWord", "class_dictionary.html#a40e5a05ba75854b0c481a792e52783f5", null ],
    [ "waitForLoading", "class_dictionary.html#a01a4173f38751ea1dc624431984a730a", null ],
    [ "engine", "class_dictionary.html#a0ba21b522d5d608705d5d6cc0134b078", null ]
];