var _drawable_object_8h =
[
    [ "DrawableObject", "class_drawable_object.html", "class_drawable_object" ],
    [ "windowScale", "_drawable_object_8h.html#a5c8d625af0f0eabf783c47c8cce202c5", null ]
];