var searchData=
[
  ['activeplayer_0',['activePlayer',['../class_game_engine.html#af075a77b7de3efa2b256957a7c59cdfd',1,'GameEngine']]]
];
