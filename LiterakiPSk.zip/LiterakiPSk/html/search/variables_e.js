var searchData=
[
  ['speed_0',['speed',['../class_drawable_object.html#a0215d6bec1e1668d0df439c5c8e143b1',1,'DrawableObject']]],
  ['sprites_1',['sprites',['../class_drawable_object.html#a1950db1955de6c924dad1f606bb3311b',1,'DrawableObject']]]
];
