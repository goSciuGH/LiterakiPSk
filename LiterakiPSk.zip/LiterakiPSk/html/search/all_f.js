var searchData=
[
  ['searchword_0',['searchWord',['../class_dictionary.html#a40e5a05ba75854b0c481a792e52783f5',1,'Dictionary']]],
  ['speed_1',['speed',['../class_drawable_object.html#a0215d6bec1e1668d0df439c5c8e143b1',1,'DrawableObject']]],
  ['sprites_2',['sprites',['../class_drawable_object.html#a1950db1955de6c924dad1f606bb3311b',1,'DrawableObject']]]
];
