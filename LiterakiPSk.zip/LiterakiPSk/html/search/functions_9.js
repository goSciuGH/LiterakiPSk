var searchData=
[
  ['searchword_0',['searchWord',['../class_dictionary.html#a40e5a05ba75854b0c481a792e52783f5',1,'Dictionary']]]
];
