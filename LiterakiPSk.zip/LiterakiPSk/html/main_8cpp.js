var main_8cpp =
[
    [ "main", "main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "boardLetterBonuses", "main_8cpp.html#ae9459e1f8e119f46adb7e077e16b68b8", null ],
    [ "boardWordBonuses", "main_8cpp.html#a17db3546515c5f9038e4e281eac2ff54", null ],
    [ "fonts", "main_8cpp.html#a928b77f05ac0535114e4f568cfc7ca25", null ],
    [ "FULLRES_H", "main_8cpp.html#ac6cd81fe4cf179b8e18057cca11e4474", null ],
    [ "FULLRES_W", "main_8cpp.html#afd26f723db14fccff3af203cb886abca", null ],
    [ "fullScreen", "main_8cpp.html#ad42a73c9228e7688f25d1f2364a576db", null ],
    [ "textures", "main_8cpp.html#a1bb97d3f40502b1ece064ba00e879f6e", null ],
    [ "windowH", "main_8cpp.html#a39edee3bbe6094e4d11dcc6646ebcb51", null ],
    [ "windowScale", "main_8cpp.html#a5c8d625af0f0eabf783c47c8cce202c5", null ],
    [ "windowW", "main_8cpp.html#a39dc59daa5aecfcffa0386f6fc796719", null ]
];